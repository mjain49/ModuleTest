package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.entities.Trainee;
import com.cg.exceptions.ApplicationException;


public class TraineeDAOImpl implements TraineeDAO{

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager manager = factory.createEntityManager();
	
	public boolean add(Trainee trainee) {
		try{
			manager.getTransaction().begin();
			manager.persist(trainee);
			manager.getTransaction().commit();
			return true;
		}catch(Exception e) {
			throw new ApplicationException("Trainee "+trainee+" Not added to database");
		}
		
	}

	public boolean delete(Trainee trainee) {
		try {
			manager.getTransaction().begin();
			manager.remove(trainee);
			manager.getTransaction().commit();
			return true;
		}catch(Exception e) {
			throw new ApplicationException("Trainee "+trainee+" Not deleted");
		}
	}

	public Trainee find(Integer id) {
		Trainee trainee = manager.find(Trainee.class, id);
		if(trainee!=null) {
			return trainee;
		}else {
			throw new ApplicationException("Trainee with ID : "+id+" Not present in database");
		}
	}

	public List<Trainee> getAll() {
		Query query = manager.createNamedQuery("getall",Trainee.class);
		List<Trainee> list = query.getResultList();
		if(!list.isEmpty()) {
			return list;
		}else {
			throw new ApplicationException("No Trainee Present in Database");
		}
	}

	public Trainee update(Trainee trainee) {
		try {
			manager.getTransaction().begin();
			Trainee temp = manager.find(Trainee.class, trainee.getId());
			temp.setName(trainee.getName());
			temp.setDomain(trainee.getDomain());
			temp.setLocation(trainee.getLocation());
			manager.getTransaction().commit();
			return trainee;
		}catch(Exception e) {
			e.printStackTrace();
			throw new ApplicationException("Trainee "+trainee+" Not updated");
		}
	}
}
