package com.cg.service;

import java.util.List;

import com.cg.entities.Trainee;

public interface TraineeService {
	public boolean addTrainee(Trainee trainee);
	public boolean deleteTrainee(Trainee trainee);
	public Trainee updateTrainee(Trainee trainee);
	public Trainee findTrainee(Integer id);
	public List<Trainee> getAllTrainee();
}
