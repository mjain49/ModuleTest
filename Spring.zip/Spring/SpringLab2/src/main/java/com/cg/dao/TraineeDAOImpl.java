package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.entities.Trainee;


public class TraineeDAOImpl implements TraineeDAO{

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager manager = factory.createEntityManager();
	
	public boolean add(Trainee trainee) {
		try{
			manager.getTransaction().begin();
			manager.persist(trainee);
			manager.getTransaction().commit();
			return true;
		}catch(Exception e) {
			return false;
		}
		
	}

	public boolean delete(Trainee trainee) {
		try {
			manager.getTransaction().begin();
			manager.remove(trainee);
			manager.getTransaction().commit();
			return true;
		}catch(Exception e) {
			return false;
		}
	}

	public Trainee find(Integer id) {
		return manager.find(Trainee.class, id);
	}

	public List<Trainee> getAll() {
		Query query = manager.createNamedQuery("getall",Trainee.class);
		List<Trainee> list = query.getResultList();
		return list;
	}

	public Trainee update(Trainee trainee) {
		try {
			manager.getTransaction().begin();
			Trainee temp = manager.find(Trainee.class, trainee.getId());
			temp.setName(trainee.getName());
			temp.setDomain(trainee.getDomain());
			temp.setLocation(trainee.getLocation());
			manager.getTransaction().commit();
			return trainee;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
