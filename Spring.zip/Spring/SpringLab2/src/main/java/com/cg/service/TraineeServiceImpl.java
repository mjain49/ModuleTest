package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.TraineeDAO;
import com.cg.dao.TraineeDAOImpl;
import com.cg.entities.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService{

	
	TraineeDAO dao = new TraineeDAOImpl();
	
	@Transactional(propagation=Propagation.REQUIRED)
	public boolean addTrainee(Trainee trainee) {
		return dao.add(trainee);
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public boolean deleteTrainee(Trainee trainee) {
		try {
			return dao.delete(trainee);
		}catch(Exception e) {
			return false;
		}
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public Trainee updateTrainee(Trainee trainee) {
		try {
			return dao.update(trainee);
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Transactional(readOnly=true)
	public Trainee findTrainee(Integer id) {
		return dao.find(id);
	}

	@Transactional(readOnly=true)
	public List<Trainee> getAllTrainee() {
		return dao.getAll();
	}

}
