package stepDefinition;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {

	@Given("^The System must provide the ability to view User Id$")
	public void the_System_must_provide_the_ability_to_view_Equipment_Tag() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		// throw new PendingException();
	}

	@When("^User enters the query based on the equipments matching criterion$")
	public void user_enters_the_query_based_on_the_equipments_matching_criterion() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Enter your Query for retreiving ");
	}

	@Then("^System return a list of equipments  based on the query entered by user$")
	public void system_return_a_list_of_equipments_based_on_the_query_entered_by_user() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("System show List of Equipments");
	}

	@Then("^provide User Id  for each equipment record returned in the list$")
	public void provide_User_Id_for_each_equipment_record_returned_in_the_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("System Show User Id for each equipment record returned in the list");
	}

}
