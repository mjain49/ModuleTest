package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageBean.RegisterPageFactory;

public class TestClass {

	private WebDriver driver;
	private RegisterPageFactory rpf;
	
	@Before//called first before everyother methods
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\\\softwares\\\\chromedriver_win32\\\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("^User is on 'register' Page$")
	public void user_is_on_register_Page() throws Throwable {
	//for displaying success.html page
	driver.get("D:\\BDD Workspace\\RegistrationMj\\target\\register.html");   
	rpf=new RegisterPageFactory(driver);  
	}

	@When("^User Enters Invalid UserName$")
	public void user_Enters_Invalid_UserName() throws Throwable {
	rpf.setName("");
	rpf.setLoginButton();
	}

	@Then("^display 'Please Enter Valid UserName'$")
	public void display_Please_Enter_Valid_UserName() throws Throwable {
	String expectedMessage="*Please Enter UserName";
	String acctualMessage=rpf.getNameError().getText();
	Assert.assertEquals(expectedMessage, acctualMessage);
	driver.close();
	}

	@When("^User Enters Invalid Address$")
	public void user_Enters_Invalid_Address() throws Throwable {
	rpf.setName("Mayur");
	rpf.setAddress("");
	rpf.setLoginButton();
	}

	@Then("^display 'Please Enter Valid Address'$")
	public void display_Please_Enter_Valid_Address() throws Throwable {
		String expectedMessage="*Please Enter Address";
		String acctualMessage=rpf.getAddressError().getText();
		Assert.assertEquals(expectedMessage, acctualMessage);
		driver.close();
	}

	@When("^User Enters Invalid Marks$")
	public void user_Enters_Invalid_Marks() throws Throwable {
		rpf.setName("Mayur");
		rpf.setAddress("Capgemini");
		rpf.setMarks("");
		rpf.setLoginButton();    
	}

	@Then("^display 'Please Enter Valid Marks'$")
	public void display_Please_Enter_Valid_Marks() throws Throwable {
		String expectedMessage="*Please Enter Marks";
		String acctualMessage=rpf.getMarksError().getText();
		Assert.assertEquals(expectedMessage, acctualMessage);
		driver.close();    
	}

	@When("^User Enters Invalid Details$")
	public void user_Enters_Invalid_Details() throws Throwable {
		rpf.setName("Mayur");
		rpf.setAddress("Capgemini");
		rpf.setMarks("80");
		rpf.setLoginButton();    
	}

	@Then("^display 'Invalid Register Please try again'$")
	public void display_Invalid_Register_Please_try_again() throws Throwable {
		String expectedMessage="*Please Enter Valid Details";
		String acctualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, acctualMessage);
		driver.switchTo().alert().accept();
		driver.close();     
	}

	@When("^User Enters Valid Details$")
	public void user_Enters_Valid_Details() throws Throwable {
		rpf.setName("Mayur");
		rpf.setAddress("Capgemini");
		rpf.setMarks("100");
		rpf.setLoginButton();      
	}

	@Then("^display 'success' Page$")
	public void display_success_Page() throws Throwable {
	driver.get("D:\\BDD Workspace\\RegistrationMj\\target\\success.html");    
	}
}
